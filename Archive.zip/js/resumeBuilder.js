var bio = {
        "name": "Michael J. Wiebe",
        "role": "Full-Stack Web Developer",
        "skills": ["HTML", "CSS", "JS", "Ruby", "Rails", "Process Improvement", "Lean Principles and Methodology", "Spanish and French"],
        "biopic": "images/johanAndMe.jpg",
        "welcomeMessage": "Thank you for visiting my site. Have a look around!",
        "contact": {
            "location": "Philadelphia, Pennsylvania",
            "email": "michaelwiebe@email.com",
            "mobile": "1-574-123-4567",
            "skype": "michaelwiebe00",
            "github": "<a id='github' href='https://github.com/michaeljwiebe'>github.com/michaeljwiebe</a>"
        },
        "display": function() {
            var formattedName = HTMLheaderName.replace("%data%", bio.name);
            var formattedRole = HTMLheaderRole.replace("%data%", bio.role);
            var formattedBioPic = HTMLbioPic.replace("%data%", bio.biopic);
            $("#header").prepend(formattedRole);
            $("#header").prepend(formattedName);
            $("#header").prepend(formattedBioPic);
            var formattedWelcomeMsg = HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);
            $("#header").append(formattedWelcomeMsg);
            if (bio.skills.length > 0) {
                $("#header").append(HTMLskillsStart);
                var i = 0;
                while (i < bio.skills.length) {
                    var formattedSkill = HTMLskills.replace("%data%", bio.skills[i]);
                    $("#skills").append(formattedSkill);
                    i++;
                }
            }
            var contactDisplay = function() {
                    var formattedMobile = HTMLmobile.replace("%data%", bio.contact.mobile);
                    var formattedEmail = HTMLemail.replace("%data%", bio.contact.email);
                    var formattedSkype = HTMLcontactGeneric.replace("%contact%", "skype").replace("%data%", bio.contact.skype);
                    var formattedGithub = HTMLgithub.replace("%data%", bio.contact.github);
                    var formattedLocation = HTMLlocation.replace("%data%", bio.contact.location);
                    $("#topContacts").append(formattedMobile, formattedEmail, formattedSkype, formattedGithub, formattedLocation);
                    $("#footerContacts").append(formattedMobile, formattedEmail, formattedSkype, formattedGithub, formattedLocation);
            };
            contactDisplay();
        }
      };
        bio.display();


        var work = {
            jobs: [{
                "employer": "Aluminum Trailer Company",
                "yearsWorked": 2,
                "dates": "07/2014 to 06/2016",
                "location": "Nappanee, Indiana",
                "title": "PI and Training Coordinator",
                "description": "Adapted training system and methodology for use in factory and applied improvements in various environments",
                "location": "Nappanee, Indiana"
            }, {
                "employer": "Hope Builders Group",
                "yearsWorked": 1,
                "dates": "06/2013 to 06/2014",
                "location": "Elkhart, Indiana",
                "title": "Lean Change Agent",
                "description": "Initiated and drove cultural change across organization",
                "location": "Elkhart, Indiana"
            }]
          };
        work.display = function() {
            work.jobs.forEach(function(job) {
                $("#workExperience").append(HTMLworkStart);
                var formattedEmployer = HTMLworkEmployer.replace("%data%", job.employer);
                var formattedTitle = HTMLworkTitle.replace("%data%", job.title);
                var formattedEmployerTitle = formattedEmployer + formattedTitle;
                $(".work-entry:last").append(formattedEmployerTitle);
                var formattedDate = HTMLworkDates.replace("%data%", job.dates);
                $(".work-entry:last").append(formattedDate);
                var formattedDescription = HTMLworkDescription.replace("%data%", job.description);
                $(".work-entry:last").append(formattedDescription);
                var formattedLocation = HTMLworkLocation.replace("%data%", job.location);
                $(".work-entry:last").append(formattedLocation);
            });
        };
        work.display();

        var education = {
            "schools": [{
                "name": "New York Code and Design Academy",
                "majors": ["Web Development Intensive"],
                "degree": "Certificate",
                "location": "Philadelphia, PA",
                "date": "April - June 2017"
            }, {
                "name": "Goshen College",
                "majors": ["Environmental Science"],
                "degree": "Bachelor's",
                "location": "Goshen, Indiana",
                "date": "2011 - 2013"
            }, {
                "name": "Purdue University",
                "majors": ["Biology"],
                "degree": "no degree",
                "location": "West Lafayette, Indiana",
                "date": "2007 - 2008"
            }],
            "onlineCourses": [{
                "name": "Front-End Nanodegree",
                "title": "Udacity",
                "classes": "HTML, CSS, JS, jQuery",
                "degreeURL" : "https://www.udacity.com/course/front-end-web-developer-nanodegree--nd001",
                "url": "http://www.udacity.com",
                "date": "January - April 2017"
            }]
        };

        education.display = function() {
            education.schools.forEach(function(ed) {
                $("#education").append(HTMLschoolStart);
                var formattedSchoolName = HTMLschoolName.replace("%data%", ed.name);
                var formattedDegree = HTMLschoolDegree.replace("%data%", ed.degree);
                $(".education-entry:last").append(formattedSchoolName).append(formattedDegree);
                var formatteddate = HTMLschoolDates.replace("%data%", ed.date);
                $(".education-entry:last").append(formatteddate);
                var formattedMajor = HTMLschoolMajor.replace("%data%", ed.majors);
                $(".education-entry:last").append(formattedMajor);
                var formattedLocation = HTMLschoolLocation.replace("%data%", ed.location);
                $(".education-entry:last").append(formattedLocation);
            });
            $("#education").append(HTMLonlineClasses);
            $("#education").append(HTMLschoolStart);

            education.onlineCourses.forEach(function(online) {
                var formattedSchoolName = HTMLonlineSchool.replace("%data%", online.name);
                var formattedTitle = HTMLonlineTitle.replace("%data%", online.title).replace("#", online.degreeURL);
                $(".education-entry:last").append(formattedTitle).append(formattedSchoolName);
                var formattedClasses = HTMLonlineCourses.replace("%data%", online.classes);
                $(".education-entry:last").append(formattedClasses);
                var formatteddate = HTMLonlineDates.replace("%data%", online.date);
                $(".education-entry:last").append(formatteddate);
                var formattedURL = HTMLonlineURL.replace("%data%", online.url).replace("#", online.url);
                $(".education-entry:last").append(formattedURL);

            });
        };
        education.display();

        var projects = {
            "projects": [{
                "url": "http://www.michaelwiebe.net",
                "date": "February 2017",
                "title": "Semi-Professional Photography Portfolio",
                "description": "Photography exhibition",
                "images": [
                    "images/portrait.jpg",
                    "images/flower.jpg",
                    "images/dance.jpg",
                    "images/party.jpg"
                ]
            }, {
                "url": "http://www.github.com/michaeljwiebe",
                "date": "March 2017",
                "title": "Web Development Portfolio",
                "images": ["images/github.png"],
                "description": "exhibition of JavaScript and jQuery skills"
            }]
        };

        projects.display = function() {
            projects.projects.forEach(function(project) {
                $("#projects").append(HTMLprojectStart);
                var formattedProjectTitle = HTMLprojectTitle.replace("%data%", project.title).replace("#", project.url);
                $(".project-entry:last").append(formattedProjectTitle);
                var formattedProjectdate = HTMLprojectDates.replace("%data%", project.date);
                $(".project-entry:last").append(formattedProjectdate);
                var formattedProjectDescription = HTMLprojectDescription.replace("%data%", project.description);
                $(".project-entry:last").append(formattedProjectDescription);
                project.images.forEach(function(image) {
                    var formattedProjectImage = HTMLprojectImage.replace("%data%", image);
                    $(".project-entry:last").append(formattedProjectImage);
                });
            });
        };
        projects.display();

        $("#mapDiv").append(googleMap);

        // $("#main").append(internationalizeButton);
        //
        // function inName(name) {
        //     name = name.trim().split(" ");
        //     name[1] = name[1].toUpperCase();
        //     name[0] = name[0].slice(0, 1).toUpperCase() + name[0].slice(1).toLowerCase();
        //     return name[0] + " " + name[1];
        // }
        //
        // console.log(inName("michael wiebe"));
